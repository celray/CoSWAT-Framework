#!/bin/bash

python3 "${HOME}/.local/share/QGIS/QGIS3/profiles/default/python/plugins/QSWATPlusLinux3_64/swatgraph.py" %1
